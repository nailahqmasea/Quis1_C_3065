/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quis1_c_3065;

/**
 *
 * @author Nailah Qothrunnada Maryana Septeardi
 * NIM : 21103065
 */
public class Dosen extends Penduduk {
    String NIDN_3065,gol_3065;
    int gajiPokok_3065,tunjangan_3065;
    double gajitotal_3065;
    
    public double totalPendapatan(){
        switch(gol_3065){
            case "IIIA":
                tunjangan_3065 = 300000;
            break;
            case "IIIB":
                tunjangan_3065 = 500000;
            break;
            case "IIIC":
                tunjangan_3065 = 700000;
            break;
        }
        gajitotal_3065 = gajiPokok_3065 + tunjangan_3065;
        return gajitotal_3065;
    }
    public void tampilDataDosen(){
        tampilDataPenduduk();
        System.out.println("NIDN           :"+NIDN_3065);
        System.out.println("Golongan       :"+gol_3065);
        System.out.println("Gaji Pokok     :"+gajiPokok_3065);
    }
}
