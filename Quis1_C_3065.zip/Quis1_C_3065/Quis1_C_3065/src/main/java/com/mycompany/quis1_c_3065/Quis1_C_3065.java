/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.quis1_c_3065;

/**
 *
 * @author Nailah Qothrunnada Maryana Septeardi
 * NIM : 21103065
 */
import java.io.*;
public class Quis1_C_3065 {

    public static void main(String[] args) {
        Mahasiswa A = new Mahasiswa();
        Mahasiswa B = new Mahasiswa();
        Dosen C = new Dosen();
        Dosen D = new Dosen();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        try{
            System.out.println("NIK     : ");
            A.NIK_3065 = br.readLine();
            System.out.println("Nama    : ");
            A.nama_3065 = br.readLine();
            System.out.println("Umur    : ");
            A.umur_3065 = Integer.parseInt(br.readLine());
            System.out.println("Alamat  : ");
            A.alamat_3065 = br.readLine();
            System.out.println("NIM     : ");
            A.nim_3065 = br.readLine();
            System.out.println("IPK     : ");
            A.ipk_3065 = Float.parseFloat(br.readLine());
            System.out.println();
            
            System.out.println("NIK     : ");
            B.NIK_3065 = br.readLine();
            System.out.println("Nama    : ");
            B.nama_3065 = br.readLine();
            System.out.println("Umur    : ");
            B.umur_3065 = Integer.parseInt(br.readLine());
            System.out.println("Alamat  : ");
            B.alamat_3065 = br.readLine();
            System.out.println("NIM     : ");
            B.nim_3065 = br.readLine();
            System.out.println("IPK     : ");
            B.ipk_3065 = Float.parseFloat(br.readLine());
            System.out.println();
            
            System.out.println("NIK             : ");
            C.NIK_3065 = br.readLine();
            System.out.println("Nama            : ");
            C.nama_3065 = br.readLine();
            System.out.println("Umur            : ");
            C.umur_3065 = Integer.parseInt(br.readLine());
            System.out.println("Alamat          : ");
            C.alamat_3065 = br.readLine();
            System.out.println("NIDN            : ");
            C.NIDN_3065 = br.readLine();
            System.out.println("Golongan        : ");
            C.gol_3065 = br.readLine();
            System.out.println("Gaji Pokok      : ");
            C.gajiPokok_3065 = Integer.parseInt(br.readLine());
            System.out.println("");
            
            System.out.println("NIK             : ");
            D.NIK_3065 = br.readLine();
            System.out.println("Nama            : ");
            D.nama_3065 = br.readLine();
            System.out.println("Umur            : ");
            D.umur_3065 = Integer.parseInt(br.readLine());
            System.out.println("Alamat          : ");
            D.alamat_3065 = br.readLine();
            System.out.println("NIDN            : ");
            D.NIDN_3065 = br.readLine();
            System.out.println("Golongan        : ");
            D.gol_3065 = br.readLine();
            System.out.println("Gaji Pokok      : ");
            D.gajiPokok_3065 = Integer.parseInt(br.readLine());
            System.out.println("");
            
            System.out.println("==== DATA MAHASISWA ====");
            A.tampilDataMahasiswa();
            A.tampilDataBeasiswa();
            System.out.println("");
            B.tampilDataMahasiswa();
            B.tampilDataBeasiswa();
            System.out.println("====== DATA DOSEN ======");
            C.tampilDataDosen();
            System.out.println("Total Pendapatan    : Rp "+C.totalPendapatan());
            System.out.println("");
            D.tampilDataDosen();
            System.out.println("Total Pendapatan    : Rp "+D.totalPendapatan());
            System.out.println("");
        }
           catch(Exception ex){
               System.out.println("ex");
           }
    }
}
