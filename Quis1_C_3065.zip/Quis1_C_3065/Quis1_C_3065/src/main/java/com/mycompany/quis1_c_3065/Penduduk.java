/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quis1_c_3065;

/**
 *
 * @author Nailah Qothrunnada Maryana Septeardi
 * NIM : 21103065
 */
public class Penduduk {
    String NIK_3065, nama_3065, alamat_3065;
    int umur_3065;
    
    public void tampilDataPenduduk(){
        System.out.println("NIK               : " + NIK_3065);
        System.out.println("Nama              : " + nama_3065);
        System.out.println("Umur              : " + umur_3065);
        System.out.println("Alamat            : " + alamat_3065);
    }
}
