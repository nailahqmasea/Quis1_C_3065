/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quis1_c_3065;

/**
 *
 * @author Nailah Qothrunnada Maryana Septeardi
 * NIM : 21103065
 */
public class Mahasiswa extends Penduduk {
    String nim_3065;
    float ipk_3065;
    
    public void tampilDataMahasiswa(){
        tampilDataPenduduk();
        System.out.println("NIM     :"+nim_3065);
        System.out.println("IPK     :"+ipk_3065);
    }
    public void tampilDataBeasiswa(){
        if(ipk_3065 > 3.5){
            System.out.println("Mahasiswa bernama "+nama_3065+"berhak mendapatkan beasiswa");
        }else{
            System.out.println("Mahasiswa bernama "+nama_3065+"tidak berhak mendapatkan beasiswa");
        }
    }
}
